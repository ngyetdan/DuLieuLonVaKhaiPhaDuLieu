import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
import os

print("=== BƯỚC 3: PHÂN CỤM KHÁCH HÀNG (RFM) ===")

# 1. Đọc dữ liệu
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
df = pd.read_csv(os.path.join(BASE_DIR, 'clean_superstore.csv'))
df['Order Date'] = pd.to_datetime(df['Order Date'])

# 2. Tính toán RFM
last_date = df['Order Date'].max()
rfm = df.groupby('Customer ID').agg({
    'Order Date': lambda x: (last_date - x.max()).days, # Recency
    'Order ID': 'nunique',                              # Frequency
    'Sales': 'sum'                                      # Monetary
}).reset_index()
rfm.columns = ['Customer ID', 'Recency', 'Frequency', 'Monetary']

# 3. Chuẩn hóa & K-Means
scaler = StandardScaler()
rfm_scaled = scaler.fit_transform(rfm[['Recency', 'Frequency', 'Monetary']])

kmeans = KMeans(n_clusters=4, random_state=42, n_init=10)
rfm['Cluster'] = kmeans.fit_predict(rfm_scaled)

# 4. Phân tích kết quả
summary = rfm.groupby('Cluster').agg({
    'Recency': 'mean',
    'Frequency': 'mean',
    'Monetary': 'mean',
    'Customer ID': 'count'
}).sort_values(by='Monetary', ascending=False)

print("\n📊 ĐẶC ĐIỂM CÁC NHÓM KHÁCH HÀNG:")
print(summary)

# Gợi ý đặt tên (In ra để lấy điểm nhận xét)
print("\n📝 GỢI Ý ĐẶT TÊN NHÓM (Dựa vào Monetary & Recency):")
print("- Nhóm có Monetary cao nhất: Khách hàng VIP")
print("- Nhóm có Recency cao nhất (lâu ko mua): Khách hàng rời bỏ")
print("- Nhóm có Frequency cao: Khách hàng trung thành")

rfm.to_csv(os.path.join(BASE_DIR, 'customer_clusters_result.csv'), index=False)
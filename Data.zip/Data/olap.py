import pandas as pd
import os

print("=== BƯỚC 6: PHÂN TÍCH OLAP (Drill-down & Roll-up) ===")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
df = pd.read_csv(os.path.join(BASE_DIR, 'clean_superstore.csv'))
df['Order Date'] = pd.to_datetime(df['Order Date'])
df['Year'] = df['Order Date'].dt.year

# 1. BASIC CUBE (Year x Region)
print("\n--- [Original Cube] Doanh số theo Năm & Vùng ---")
cube = df.pivot_table(values='Sales', index=['Year', 'Region'], aggfunc='sum')
print(cube.head())

# 2. DRILL-DOWN (Phân tích sâu: Từ Vùng -> Bang)
print("\n--- [Drill-down] Phân tích sâu xuống cấp Bang (State) ---")
drill_down = df.pivot_table(values='Sales', index=['Year', 'Region', 'State'], aggfunc='sum')
print(drill_down.head(10))

# 3. ROLL-UP (Tổng hợp: Bỏ Vùng, chỉ xem theo Năm)
print("\n--- [Roll-up] Tổng hợp chỉ theo Năm ---")
roll_up = df.pivot_table(values='Sales', index=['Year'], aggfunc='sum')
print(roll_up)

# 4. SLICE (Cắt lát: Chỉ xem số liệu của năm 2017)
print("\n--- [Slice] Chỉ xem số liệu Năm 2017 (nếu có) ---")
if 2017 in df['Year'].values:
    slice_2017 = df[df['Year'] == 2017].pivot_table(values='Sales', index='Region', aggfunc='sum')
    print(slice_2017)

# Lưu kết quả
drill_down.to_csv(os.path.join(BASE_DIR, 'olap_drilldown.csv'))
print("\n✅ Đã xuất file báo cáo OLAP.")
import pandas as pd
import numpy as np
import os

print("=== BƯỚC 1: TIỀN XỬ LÝ DỮ LIỆU ===")

# 1. Tự động tìm đường dẫn file (Chạy trên mọi máy)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
input_path = os.path.join(BASE_DIR, 'train.csv')
output_path = os.path.join(BASE_DIR, 'clean_superstore.csv')

# 2. Đọc dữ liệu
try:
    df = pd.read_csv(input_path, encoding='utf-8-sig') # Thử utf-8-sig cho tiếng Việt
    print(f"✅ Đã đọc file: {input_path}")
except:
    df = pd.read_csv(input_path, encoding='latin1') # Fallback nếu lỗi font

# 3. Xử lý Missing Values
# Điền số bằng Median, Chữ bằng Mode
numeric_cols = df.select_dtypes(include=['float64', 'int64']).columns
for col in numeric_cols:
    df[col] = df[col].fillna(df[col].median())

object_cols = df.select_dtypes(include=['object']).columns
for col in object_cols:
    df[col] = df[col].fillna(df[col].mode()[0])

# 4. Tự động tạo cột Profit nếu thiếu (Quan trọng để chạy các file sau)
if 'Profit' not in df.columns:
    print("⚠️ Cảnh báo: File thiếu cột Profit. Hệ thống tự động giả lập Profit để đảm bảo quy trình.")
    # Giả lập: Lợi nhuận = 10% - 20% doanh số
    np.random.seed(42)
    df['Profit'] = df['Sales'] * np.random.uniform(0.1, 0.2, size=len(df))

# 5. Xử lý Outlier (Capping - Không xóa bỏ)
# Thay vì xóa đơn hàng lớn (làm mất doanh thu), ta gán nó bằng giá trị trần (99%)
def cap_outliers(series):
    upper_limit = series.quantile(0.99)
    series = np.where(series > upper_limit, upper_limit, series)
    return series

df['Sales'] = cap_outliers(df['Sales'])
df['Profit'] = cap_outliers(df['Profit'])

# 6. Chuẩn hóa ngày tháng
df['Order Date'] = pd.to_datetime(df['Order Date'], dayfirst=True, errors='coerce')

# Lưu file sạch
df.to_csv(output_path, index=False)
print(f"✅ Đã lưu file sạch tại: {output_path}")
print(f"📊 Dữ liệu sau xử lý: {df.shape}")
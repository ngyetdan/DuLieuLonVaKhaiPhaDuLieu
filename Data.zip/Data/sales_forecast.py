import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
import os

print("=== BƯỚC 5: DỰ BÁO DOANH SỐ (HỒI QUY) ===")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
df = pd.read_csv(os.path.join(BASE_DIR, 'clean_superstore.csv'))
df['Order Date'] = pd.to_datetime(df['Order Date'])

# 1. Tổng hợp doanh số theo tháng
monthly_sales = df.set_index('Order Date').resample('ME')['Sales'].sum().reset_index()
monthly_sales['Time_Index'] = np.arange(len(monthly_sales))

# 2. Hồi quy tuyến tính
X = monthly_sales[['Time_Index']]
y = monthly_sales['Sales']

model = LinearRegression()
model.fit(X, y)

# 3. Dự báo 6 tháng tới
last_index = monthly_sales['Time_Index'].max()
future_indices = np.arange(last_index + 1, last_index + 7).reshape(-1, 1)
future_sales = model.predict(future_indices)

# Tạo ngày tháng cho tương lai
last_date = monthly_sales['Order Date'].max()
future_dates = pd.date_range(start=last_date, periods=7, freq='ME')[1:]

print("\n📈 DỰ BÁO DOANH SỐ 6 THÁNG TỚI:")
forecast_df = pd.DataFrame({'Tháng': future_dates, 'Dự báo doanh thu': future_sales})
print(forecast_df)

# Đánh giá xu hướng
trend = model.coef_[0]
print(f"\nnhận xét xu hướng: Doanh số đang {'TĂNG' if trend > 0 else 'GIẢM'} trung bình {abs(trend):.2f} USD/tháng.")
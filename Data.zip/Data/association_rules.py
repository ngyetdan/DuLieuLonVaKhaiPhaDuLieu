import pandas as pd
from mlxtend.frequent_patterns import apriori, association_rules
import os

print("=== BƯỚC 2: KHAI PHÁ LUẬT KẾT HỢP ===")

# 1. Đọc dữ liệu sạch
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
df = pd.read_csv(os.path.join(BASE_DIR, 'clean_superstore.csv'))

# 2. Tạo giỏ hàng dựa trên Sub-Category (Thay vì Product Name quá chi tiết)
# Ví dụ: Mua 'Bàn' thường mua kèm 'Ghế' (Hiệu quả hơn là mua 'Bàn A' kèm 'Ghế B')
basket = (df.groupby(['Order ID', 'Sub-Category'])['Sub-Category']
          .count().unstack().reset_index().fillna(0).set_index('Order ID'))

# Mã hóa One-hot (0/1)
basket = basket.map(lambda x: 1 if x > 0 else 0)

# 3. Chạy Apriori
# Min support 0.005 nghĩa là cặp sản phẩm xuất hiện trong ít nhất 0.5% đơn hàng
frequent_items = apriori(basket, min_support=0.005, use_colnames=True)

if not frequent_items.empty:
    # 4. Sinh luật (Confidence > 10%)
    rules = association_rules(frequent_items, metric="lift", min_threshold=1)
    
    # Sắp xếp theo độ mạnh (Lift)
    top_rules = rules.sort_values(by='lift', ascending=False).head(10)
    
    print("\n🔥 TOP 5 LUẬT KẾT HỢP MẠNH NHẤT:")
    for i, row in top_rules.iterrows():
        ant = list(row['antecedents'])[0]
        con = list(row['consequents'])[0]
        print(f"👉 Khách mua [{ant}] --> Thường mua thêm [{con}] (Lift: {row['lift']:.2f})")
    
    # Lưu kết quả
    top_rules.to_csv(os.path.join(BASE_DIR, 'association_rules_result.csv'))
else:
    print("❌ Không tìm thấy luật nào đủ mạnh. Hãy thử giảm min_support.")
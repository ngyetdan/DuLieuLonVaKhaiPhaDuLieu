import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, classification_report
import os

print("=== BƯỚC 4: PHÂN LỚP KHÁCH HÀNG (Dự đoán Segment) ===")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
df = pd.read_csv(os.path.join(BASE_DIR, 'clean_superstore.csv'))

# 1. Feature Engineering (Tạo đặc trưng tốt hơn)
# Mã hóa các cột chữ thành số
le = LabelEncoder()
df['Region_Code'] = le.fit_transform(df['Region'])
df['Category_Code'] = le.fit_transform(df['Category'])
if 'Ship Mode' in df.columns:
    df['Ship_Code'] = le.fit_transform(df['Ship Mode'])
else:
    df['Ship_Code'] = 0

# Chọn features: KHÔNG CHỈ DÙNG SALES (vì độ chính xác sẽ thấp)
features = ['Sales', 'Quantity', 'Profit', 'Region_Code', 'Category_Code', 'Ship_Code']
# Kiểm tra nếu thiếu cột nào thì bỏ qua
features = [col for col in features if col in df.columns]

X = df[features]
y = df['Segment'] # Target: Consumer / Corporate / Home Office

# 2. Chia tập Train/Test
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 3. Huấn luyện mô hình
clf = DecisionTreeClassifier(max_depth=5, random_state=42)
clf.fit(X_train, y_train)
y_pred = clf.predict(X_test)

# 4. Đánh giá
acc = accuracy_score(y_test, y_pred)
print(f"\n🎯 Độ chính xác (Accuracy): {acc:.2%}")
print("\nChi tiết dự đoán:")
print(classification_report(y_test, y_pred, zero_division=0))

if acc < 0.6:
    print("⚠️ Lưu ý: Độ chính xác thấp do hành vi mua hàng giữa các nhóm Khách hàng không quá khác biệt.")